Pokrenuti projekt u Ryderu ili Visual Studio-u. 
	Ishodište aplikacije je u Program.cs-u.